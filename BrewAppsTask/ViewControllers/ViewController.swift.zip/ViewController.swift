//
//  ViewController.swift
//  BrewAppsTask
//
//  Created by sainath on 03/12/21.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var moviesCollectionView: UICollectionView!
    let path = "https://image.tmdb.org/t/p/w342"
    let poster = "https://image.tmdb.org/t/p/original"

    
    var popularMovies = [PopularMovies]()
    var repository = MoviesRespiratory()
    
    var viewState = MoviesViewState.empty {
        didSet {
            moviesCollectionView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadData()
        
    }
    
    func loadData() {
        self.repository.executePopularApiCall { (result: Result<[PopularMovies], Error>) in
            switch result {
            case .success(_):
                self.viewState = self.generateViewState(movieTypes: self.repository.popularMovies)
            case .failure:
                break
            }
        }
    }
    
    
    func remove(_ i: Int) {
        
        popularMovies.remove(at: i)
        
        let indexPath = IndexPath(row: i, section: 0)
        
        self.moviesCollectionView.performBatchUpdates({
            self.moviesCollectionView.deleteItems(at: [indexPath])
        }) { (finished) in
            self.moviesCollectionView.reloadItems(at: self.moviesCollectionView.indexPathsForVisibleItems)
        }
        
    }
    
    // MARK: - Searchbar Delegate
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        searchBar.resignFirstResponder()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar)
    {
        searchBar.text = nil
        searchBar.resignFirstResponder()
        searchBar.endEditing(true)
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        print("=> \(self.repository.popularMovies.count)")
        self.repository.popularMovies = searchText.isEmpty ? self.repository.popularMovies : self.repository.popularMovies.filter{
            
            $0.title.range(of: searchText, options: .caseInsensitive) != nil ||
                $0.overview.range(of: searchText, options: .caseInsensitive) != nil
        }
        
        moviesCollectionView.reloadData()
        print("=> \(self.repository.popularMovies.count)")
        
    }
}


extension ViewController:UICollectionViewDelegate{
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        self.performSegue(withIdentifier: ViewControllerSegue.detailVc.rawValue, sender: self)
                
    }
}


extension ViewController:UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        viewState.rows.count
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let data = viewState.rows[indexPath.row]
        switch data {
        case .popularMovie(let popularMovies):
            let cell: UnPopularMoviesCell = collectionView.dequeueReusableCell(forIndexPath: indexPath)
            cell.movieTitle.text = popularMovies.originalTitle
            cell.movieDescription.text = popularMovies.overview
            
            let url = URL(string: path + popularMovies.posterPath)!

              // Fetch Image Data
              if let data = try? Data(contentsOf: url) {
                cell.movieImageView.image = UIImage(data: data)
              }
     
            cell.buttonPressed = {
                
                self.remove(indexPath.row)
                
            }
            
            return cell
            
        case .unPopularMovie(let ratedMovies):
            
            let cell: PopularMoviesCell = collectionView.dequeueReusableCell(forIndexPath: indexPath)
            
            let url = URL(string: path + ratedMovies.backdropPath)!

              // Fetch Image Data
              if let data = try? Data(contentsOf: url) {
                cell.PopularMovieImage.image = UIImage(data: data)
              }
  
            
            cell.buttonPressed = {
                
                self.remove(indexPath.row)
                
            }
            
            return cell
        default:
            return UICollectionViewCell()
        }
    }
}

extension ViewController: UICollectionViewDelegateFlowLayout{
 
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let data = viewState.rows[indexPath.row]
        switch data {
//        case .popularMovie:
//            return CGSize(width: (collectionView.frame.width/1 - 10), height: 230)
        case .unPopularMovie:
            return CGSize(width: (collectionView.frame.width/1 - 10), height: 320)
        default:
            return CGSize.zero
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
            UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        5.0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        5.0
    }
}


extension ViewController: SegueHandler {
    // MARK: - Navigation
    enum ViewControllerSegue: String {
        case detailVc
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segueIdentifierCase(for: segue) {
        case .detailVc:
            break
        default:
            break
        }
    }
}


extension ViewController {
    func generateViewState(movieTypes: [PopularMovies]) -> MoviesViewState {
        for movie in movieTypes {
            viewState.rows.append(.popularMovie(movie))
        }
        return viewState
    }
}
